import { Link } from "react-router-dom";
import { useState } from "react";
import "./navigation.scss";

function Navigation() {
  const [tab, setTab] = useState(0);

  return (
    <nav className="navigation">
      {/* js 이벤트 3event Ex7 참고 */}

      <div className="btnContainer">
        <div
          className={`navBtn ${tab === 0 ? "on" : null}`}
          onClick={() => setTab(0)}
        >
          <Link to="/">Projects</Link>
        </div>

        <div
          className={`navBtn ${tab === 1 ? "on" : null}`}
          onClick={() => setTab(1)}
        >
          <Link to="/about">About Me</Link>
        </div>
      </div>
    </nav>
  );
}

export default Navigation;
