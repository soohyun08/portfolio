export default [
  {
    id: 1,
    name: "메타토이 드레곤즈",
    logoImg: "/images/header_logo.png",
    img: "/images/metaToyDragonZ-mainPage.png",
    device: " WEB ",
    tool: "JavaScript(ES6+)",
    team: "Team of 4 members",
  },
  {
    id: 2,
    name: "케이테마 인테리어",
    logoImg: "/images/InteriorWhite.png",
    img: "/images/interiorK.PNG",
    device: " WEB ",
    tool: "React",
    team: "Personal project",
  },
  /* { id: 3 , name: , logoImg:, img: , des: , url: },
      { id: 4 , name: , logoImg:, img: , des: , url: }, */
];
